% 
% This script returns a spatial selection of events
% contained in a seismic catalog given a selection 
% polygon that determines the area of interest. 
%
% INPUT
%
% Catalog : Seismic catalog Data in ZMAP format; 
% 
% Polygon : Selection polygon in two-columns LON LAT format.
% 
% OUTPUT
%
% Figure : figure with coastlines map, epicenters of the 
%          events, selection polygon, and legend
%
% Catalog_Ok : seismic catalog in polygon in ZMAP format
%

% Import data
Catalog = importdata("Catalog.txt");

% Import polygon
Polygon = importdata("Polygon.txt");

% Identification of geographical limits of interest
LatMax = max(Catalog(:,2)) + 0.5;
LatMin = min(Catalog(:,2)) - 0.5;
LonMax = max(Catalog(:,1)) + 0.5;
LonMin = min(Catalog(:,1)) - 0.5;

% Generate figure
figure

% Setting geographic limits
ylim([LatMin LatMax]);
xlim([LonMin LonMax]);

% Active hold on figure
hold on

% Active box on figure
box on

% Plot Coastlines
load coastlines
plot(coastlon,coastlat,"black",DisplayName ='Coast Lines');

% Create legend
lg = legend;

% Plot catalog
%scatter(Data(:,1), Data(:,2), 3.^Data(:,6), Data(:,7), 'filled', DisplayName='Epicenters' );
scatter(Catalog(:,1), Catalog(:,2), 2, Catalog(:,7), 'filled', DisplayName='Epicenters' );
cbar = colorbar ;
cbar.Label.String = 'Depth (km)';
%plot(Data(:,1), Data(:,2), LineStyle="none", Marker=".");

% Plot polygon    
plot(Polygon(:,1),Polygon(:,2),'r',DisplayName ='Polygon')

% Deactivate hold on figure
hold off

% Output of seismic catalog selection
Catalog_Ok = Catalog(inpolygon( Catalog(:,2) , Catalog(:,1) , Polygon(:,2) , Polygon(:,1) ) , : ) ;

% Save cut seismic catalog
save(fullfile("Catalog_1.txt"), 'Catalog_Ok', '-ascii');