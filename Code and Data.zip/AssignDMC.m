function [ Cat_New ] = AssignDMC( Cat , MC , M1 , T1 , DMC1 , M2 , T2 , DMC2 , M3 , T3 , DMC3 )

% INPUT
%
% Cat = catalog in ZMAP format
%
% MC  = magnitude of completeness of the catalog
%
% M1 , M2 , M3 = magnitudes for the STAI (short-term aftershock incompleteness) 
%                computation
%                 !!! M1 <= M2 <= M3
%
% T1 , T2 , T3 = time windows for the STAI computation
%                 !!! T1 <= T2 <= T3
%
% DMC1 , DMC2 , DMC3 = delta for the completeness magnitude (how much we
%                      have to increase the completeness level)
%                 !!! DMC1 <= DMC2 <= DMC3
%
%
% OUTPUT
%
% Cat_New = new catalog with the 11-th containing the magnitude of
%           completeness, adjusted for STAI


% preallocation of the new catalog (11-th column is equal to MC at the beginning )
% the first 10 columns are the same of the original catalog
Cat_New               = zeros( size( Cat , 1 ) , 11 ) ;
Cat_New( : , 11 )     = MC ;
Cat_New( : , 1 : 10 ) = Cat ;

% times of all events in the catalog
Times = datenum( Cat( : , [ 3 : 5 , 8 : 10] ) ) ;

% open waitbar
f = waitbar(0,'Please wait...');
pause(2)

% 'for' loop to assign the proper DMC ;
for i = 2 : size( Cat , 1 )

    % Part1: M1 , T1 , DMC1

    % magnitude selection according to T1
    M_Temp = Cat( ( Times >  ( Times(i) - T1 ) ) & ( Times < Times(i) ) , 6 ) ;                           
                              
    % if the maximum of all the selected magnitudes is larger than M1 
    if max( M_Temp ) >= M1
        
        % add DM1 to the completeness (11-th column) MC
        Cat_New( i , 11 ) = MC + DMC1 ;
    end
    
    % clear the M_Temp variable
    clear M_Temp


    % Part2: M2 , T2 , DMC2

    % magnitude selection according to T2
    M_Temp = Cat( ( Times >  ( Times(i) - T2 ) ) & ( Times < Times(i) ) , 6 ) ;                           
                              
    % if the maximum of all the selected magnitudes is larger than M2 
    if max( M_Temp ) >= M2
        
        % add DM2 to the completeness (11-th column) MC
        Cat_New( i , 11 ) = MC + DMC2 ;
    end

     % clear the M_Temp variable
    clear M_Temp


    % Part3: M3 , T3 , DMC3

    % magnitude selection according to T3
    M_Temp = Cat( ( Times >  ( Times(i) - T3 ) ) & ( Times < Times(i) ) , 6 ) ;                           
                              
    % if the maximum of all the selected magnitudes is larger than M3 
    if max( M_Temp ) >= M3
        
        % add DM2 to the completeness (11-th column) MC
        Cat_New( i , 11 ) = MC + DMC3 ;
    end

     % clear the M_Temp variable
    clear M_Temp

    % show the remaining number of iterations
    waitbar((i/size( Cat , 1 )),f,'Processing your data');

end

% close waitbar
waitbar(1,f,'Finishing');
pause(2)
delete(f)
