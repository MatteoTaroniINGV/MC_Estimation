function [D1,D2] = Magnitude_Distribution_Plot( Catalog , MagnitudeColumn , BinVector )

% compute the number of events in each magnitude bin
D1 = histcounts( Catalog( : , MagnitudeColumn ) , BinVector ) ;

% compute the cumulative distribution
D2one = cumsum( D1( end : -1 : 1 ) ) ;
D2    = D2one( end : -1 : 1 ) ;

% semi-amplitude of the bin
S_A = ( BinVector(2) - BinVector(1) )/2 ;

% plot magnitude distribution
plot( BinVector(1:end-1) + S_A , log10( D1 ) , '.r' )
hold on
plot( BinVector(1:end-1) + S_A , log10( D2 ) , 'ob' )
hold off
xlabel( 'Magnitude' )
ylabel( 'Log_{10} number of events')