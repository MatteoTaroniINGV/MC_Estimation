% This script returns a spatial selection of events
% contained in a seismic catalog given a selection 
% polygon that determines the area of interest. 
%
% The function can only be used if you are connected to internet
% because use geoplot, and geoscatter functions. 
%
% INPUT
%
% Catalog : Seismic catalog Data in ZMAP format; 
% 
% Polygon : Selection polygon in two-columns LON LAT format.
% 
% OUTPUT
%
% Figure : figure with topographic map, epicenters of the 
%          events, selection polygon, and legend
%
% Catalog_Ok : seismic catalog in polygon in ZMAP format
%

% Import data
Catalog = importdata("Catalog.txt");

% Import polygon

Polygon = importdata("Polygon.txt");

% Identification of geographical limits of interest
LatMax = max(Catalog(:,2)) + 0.5;
LatMin = min(Catalog(:,2)) - 0.5;
LonMax = max(Catalog(:,1)) + 0.5;
LonMin = min(Catalog(:,1)) - 0.5;

% Generate figure
figure

% Setting geographic limits
geolimits([LatMin LatMax],[LonMin LonMax])

% Topology Setup
geobasemap topographic

% Active hold on figure
hold on

% Active box on figure
box on

% Create legend
lg = legend;

% Plot catalog
geoscatter(Catalog(:,2), Catalog(:,1), 3.^Catalog(:,6), Catalog(:,7),Marker = ".", DisplayName='Epicenters') ;
cbar = colorbar ;
cbar.Label.String = 'Depth (km)';

% Plot polygon    
geoplot(Polygon(:,2) , Polygon(:,1),'r', DisplayName ='Polygon')

% Deactivate hold on figure
hold off

% Output of seismic catalog selection
Catalog_Ok = Catalog(inpolygon( Catalog(:,2) , Catalog(:,1) , Polygon(:,2) , Polygon(:,1) ) , : ) ;

% Save cut seismic catalog
save(fullfile("Catalog_1.txt"), 'Catalog_Ok', '-ascii');