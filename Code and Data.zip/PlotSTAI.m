function  PlotSTAI( Cat_New , MC )

% INPUT
%
% Cat_New = catalog in ZMAP format with an 11-th column, output of the 
% function 'AssignDMC'
%
% MC = magnitude of completeness of the 'Cat_New' catalog, estimated in 
% the Step 3  
%
%
% OUTPUT
%
% A figure that helps to find Short-Term Afetershock Incompleteness (STAI) 
% periods  
%
%


% number of events for the computation of the rolling window means
% (in this case is 100, but it can be changed)
Num_Ev = 10^2 ;

% selection of the events according to the magnitude
% (in this case we selected all the evets above MC - 0.5 , but it can be
% changed)
Cat_New_Ok = Cat_New( Cat_New( : , 6 ) >= MC - 0.5 , : ) ;

% preallocation of the 'Mean_Magn' vector
Mean_Magn = zeros( 1 ,  size( Cat_New_Ok , 1 ) - Num_Ev + 1) ;

% loop 'for' to compute the rolling window mean
for i = 1 : size( Cat_New_Ok , 1 ) - Num_Ev + 1
    
    % compute the mean of the magnitudes of the events from the 
    % 'i'-th to the 'i+Num_Ev-1'-th
    Mean_Magn( i ) = mean( Cat_New_Ok( i : i + Num_Ev - 1 , 6 ) , 'omitnan' ) ;
end



% plot of the magnitudes, the rolling window means, and the global mean
figure

% magnitudes plot
Marker_Size = 2 ;
Ind1 = find( Cat_New_Ok( : , 11 ) <= MC ) ; % find the events with completeness <= MC
Ind2 = find( Cat_New_Ok( : , 11 ) > MC )  ; % find the events with completeness > MC (potentially
                                            % affected by STAI)

plot( Ind1 , Cat_New_Ok( Ind1 , 6 ) , '.b' , 'MarkerSize' , Marker_Size )
hold on
plot( Ind2 , Cat_New_Ok( Ind2 , 6 ) , '.r' , 'MarkerSize' , Marker_Size )

% the rolling window means plot
X = 1 : 1 : size( Cat_New_Ok , 1 ) - Num_Ev + 1 ;
plot( X , Mean_Magn , '.y' )

% the magntitude of completeness threshold plot
plot( [ 1 , size( Cat_New_Ok , 1 ) ] , [ MC , MC ] , 'm' , 'LineWidth', 2 )

% plot options
box on
xlim( [ 0 , size( Cat_New_Ok , 1 ) ] )
ylim( [ min( Cat_New_Ok( : , 6 ) ) , max( Cat_New_Ok( : , 6 ) ) + 0.2 ] )
xlabel( 'Incremental number' )
ylabel( 'Magnitude' )
legend('Seismic events' , 'STAI' , 'Mean Magnitude' , 'Mc')

