% Script Step 4:
%
% Computation of the magnitude of completeness for Short Term Aftershorck
% Incompleteness (STAI) periods; this step requires a lot of subjective
% choices; this script will help to document these choices and to check the
% reliability of the completeness through the method of Zhuang et al. 2017
% intergated with the considerations of Taroni et al. 2021

% magnitude of completeness estimated in Step 3 
Mc = 1.8 ;

% minimum magnitude of selected events in the catalog; it is useful to 
% check the reliability of the estimated completeness during STAI periods 
% (suggestion: use 'Mc - 0.5' can be ok) 
Magn_Min = 1.3 ;

% load the seismic catalog of Step 3
Cat_Raw = importdata( 'Catalog_3.txt') ;


% select the events of seismic catalog above 'Magn_Min'
Cat = Cat_Raw( Cat_Raw( : , 6 ) >= Magn_Min , : ) ;

% assign different magnitude of completeness after strong events, i.e.
% assessing STAI problem using the function "AssignDMC": this function
% requires 8 different inputs, please go to the function for details
[ Cat_New ] = AssignDMC( Cat , Mc , 5.0 , 0.5 , 0.2 , 5.5 , 0.5 , 0.4 , 6.0 , 0.5 , 0.6 ) ;

% save the catalog with the associated completeness thresholds
save( 'Catalog_4.txt' , 'Cat_New' , '-ascii' )

% plot of the magnitudes, highlighting the STAI periods
PlotSTAI( Cat_New , Mc )

% plot to check the final completeness, according to the method of Zhuang 
% et al. 2017 intergated with the considerations of Taroni et al. 2021
Magn_Ok = Cat_New( Cat_New(:,6) >= Cat_New(:,11) , 6 ) - ... % select the events above the magntiude of completeness
          Cat_New( Cat_New(:,6) >= Cat_New(:,11) , 11 ) ;    % and subtract to each magnitude the relative completeness 

 % plot options
figure               
plot( Magn_Ok , '.', 'MarkerSize' , 2 , 'DisplayName' , 'Seismic Events')  
xlim( [ 1 , length( Magn_Ok)] )
xlabel( 'Incremental Number')
ylabel( 'M - MC')

% add leggend
lg = legend('Seismic events');


