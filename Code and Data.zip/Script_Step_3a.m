% The script computes the Mc of a seismic catalog in format ZMAP
% with Maximum Curvature Method.
%

% Load Seismic Catalog
Catalog = importdata("Catalog_2.txt");

% Impose correction
fMcCorrection = 0.2 ;

% Computation of Mc whith Maximum Curvature 
fMc = Calc_McMaxCurvature(Catalog);

% Apply correction
if ~isnan(fMc)
  fMc = fMc + fMcCorrection;
end

% Plot MC
fMc

% Plot Magnitude
% bin vector for the magnitude frequency distribution plot
BinVector = min( round( Catalog(:,6) , 1 ) ) : 0.1 : max( round( Catalog(:,6) , 1 ) ) + 0.1 ;

% plot the magnitude frequency distribution
subplot( 2 , 1 , 1 )
[D1,D2] = Magnitude_Distribution_Plot( Catalog , 6 , BinVector ) ;

% Add the magnitude of completeness line to the previous plot
hold on
box on
plot( [ fMc , fMc ] , [ 0 , max( log10(D2) ) + 0.2 ] , '--m' , 'LineWidth', 1.5 )
ylim( [ -0.05 , max( log10(D2) ) + 0.2 ] )
hold off

% Cut events under Mc - 1 for shortens processing times
Catalog_Ok = Catalog(Catalog(:,6) >= (fMc - 1), :);

% add the legend
legend( 'Incremental distribution' , 'Cumulative distribution' , 'Magnitude of completeness' )

% Plot for test Mc
subplot( 2 , 1 , 2 )
hold on
sizeCat = size(Catalog_Ok(:,6));
numberT = 1:1:sizeCat;
fMcT = fMc + 0 * numberT;
plot(Catalog_Ok(:,6),'.' , 'MarkerSize' , 3 );
plot(numberT, fMcT, '-m' , 'LineWidth', 1.5 );
box on
xlabel( 'Incremental number' )
ylabel( 'Magnitude')
hold off

% add the legend
legend( 'Events' , 'Mc') 

% Save cut seismic catalog
save(fullfile("Catalog_3.txt"), 'Catalog_Ok', '-ascii');