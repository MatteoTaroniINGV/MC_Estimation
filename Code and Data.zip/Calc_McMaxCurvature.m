function [ MC ] = Calc_McMaxCurvature( Catalog )

% define the bin vector
BinVector = min( round( Catalog(:,6) , 1 ) ) : 0.1 : max( round( Catalog(:,6) , 1 ) ) ;

% compute the number of events in each magnitude bin
D1 = histcounts( Catalog( : , 6) , BinVector ) ;

% find the bin with the largest number of events
Ind = find( D1 == max(D1) ) ;

% compute the MC as the value of magnitude correponding to the bin with the
% largest number of events
% (e.g. if the bin corresponding at the magnitudes 2.1-2.2 contains the
% largest number of events, the correspondig MC will be 2.2
MC = BinVector( max( Ind) + 1 ) ;





