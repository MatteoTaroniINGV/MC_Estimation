function  [ MC, P_95 , P_Mean , P_05 ] = MC_Lilliefors( Catalog , MagnCol , Bin , MC_Vect , Pval )

% warning 'off'
% (avoid warning messages in the "lillietest" function
warning('off')

% open waitbar
f = waitbar(0,'Please wait...');
pause(2)

% loop for the different completeness
for i = 1 : length( MC_Vect )
    
    % loop for the different magnitude errors (here 100 runs)
    for j = 1 : 100
        
        % add the uniform error to the magnitudes
        Magn = Catalog( : , MagnCol ) + ( rand( size( Catalog , 1 ) , 1 ) - 0.5 ) * Bin ;
        
        % magntiude selection 
        Magn_Ok = Magn( Magn >= MC_Vect( i ) ) - MC_Vect( i ) ;
        
        % Lilliefors test
        [ H , Pvalue_Lill( j , i ) ] = lillietest( Magn_Ok  , 0.05 ,  'exp' , 'MCTol' , 0.001 ) ;
        % show the remaining number of iterations
        waitbar(((j + 100 * (i - 1))/(100 * length( MC_Vect ))),f,'Processing your data');
    end  
end

% close waitbar
waitbar(1,f,'Finishing');
pause(2)
delete(f)

% compute the median p-value, and the 5-th and 95-th percentile
P_Mean = mean( Pvalue_Lill ) ;
P_05   = prctile( Pvalue_Lill ,  5 ) ;
P_95   = prctile( Pvalue_Lill , 95 ) ;

% find the magnitude of completeness (first median p-value >= Pval)
MC = min( MC_Vect( P_Mean >= Pval ) ) ;

% warning 'on'
warning('on')
