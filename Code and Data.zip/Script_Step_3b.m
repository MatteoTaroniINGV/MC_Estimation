%
% The script calcule the Mc of a seismic catalog in format ZMAP
% with Lilliefors Method.
%

% Load Seismic Catalog
Catalog = importdata("Catalog_2.txt");


% Binning of the magnitudes in the catalog
Binning = 0.01 ;

% Vector investigation of Mc 
McMAX   = 3 ;
McStep  = 0.1 ;
McMIN   = 1 ;
MC_Vect = McMIN : McStep : McMAX ;

% Impose trigger for validation (usualy 0.1 for seismic Mc)
Pval = 0.1;


% Calculaion of Mc whith Lilliefors 
[ fMc , P_95 , P_Mean , P_05 ] = MC_Lilliefors( Catalog , 6 , Binning , MC_Vect , Pval );

% plot the results of Lilliefors test
subplot( 2 , 2 , 1 )
plot( MC_Vect , P_Mean , 'k' )
hold on
plot( MC_Vect , P_05 , '--k' )
plot( MC_Vect , P_95 , '--k' )
plot( [ min( MC_Vect ) , max( MC_Vect ) ] , [ Pval , Pval ] , 'r' )
box on
xlabel( 'Completeness magnitude' )
ylabel( 'p-value Lilliefors test' )
ylim( [ 0 , 0.4 ] )
plot( [ fMc , fMc ] , [ 0 , 1 ] , 'm' , 'LineWidth', 1.5 )

% add the legend
legend( 'P_{Mean}' , 'P_{05}' , 'P_{95}' , 'p-value' , 'Mc')

% Show MC
fMc

% Plot Magnitude
% bin vector for the magnitude frequency distribution plot
BinVector = min( round( Catalog( : , 6 ) , 1 ) ) - 0.05 : 0.1 : max( round( Catalog( : , 6 ) ,  1 ) ) + 0.05 ;

% Plot the magnitude frequency distribution
subplot( 2 , 2 , 2 )
[D1,D2] = Magnitude_Distribution_Plot( Catalog , 6 , BinVector ) ;

% Add the magnitude of completeness line to the previous plot
hold on
box on
plot( [ fMc , fMc ] , [ 0 , max( log10(D2) ) + 0.2 ] , '-m' , 'LineWidth', 1.5 )
ylim( [ min( log10(D1) ) , max( log10(D2) ) + 0.2 ] )
hold off

% Cut events under Mc - 1 for shortens processing times
Catalog_Ok = Catalog(Catalog(:,6) >= (fMc - 1), :);

% add the legend
legend( 'Incremental distribution' , 'Cumulative distribution' , 'Magnitude of completeness' )

% Plot for test Mc 
subplot( 2 , 2 , [3 4] )
hold on
sizeCat = size( Catalog_Ok(:,6) , 1 ) ;
numberT = 1:1:sizeCat;
fMcT = fMc + 0 * numberT;
plot( Catalog_Ok(:,6) , '.k' , 'MarkerSize', 2 ) ;
plot(numberT, fMcT, '-m' , 'LineWidth', 1.5 ) ;
xlim( [ 1 , sizeCat ] )
ylim( [ min( Catalog_Ok(:,6) ) , max( Catalog_Ok(:,6) ) + 0.2 ] )
box on
xlabel( 'Incremental number' )
ylabel( 'Magnitude')
hold off

% add the legend
legend( 'Events' , 'Mc') 

% Save cut seismic catalog
save(fullfile("Catalog_3.txt"), 'Catalog_Ok', '-ascii');