function [ Polygon , Catalog_Ok] = Polygon_Geoplot( Catalog )

% 
% This function returns a spatial selection of events contained in a 
% seismic catalog and the selection polygon that determines the area 
% of interest.
%
% The function can only be used if you are connected to internet
% because use geoplot, and geoscatter functions. 
% 
% Once the function is started, a figure will open where it is possible 
% to draw the selection polygon using a mouse. Clicking the left mouse 
% button over the figure establishes a new point of the polygon. You must
% draw at least 3 points to start the selection correctly, and at least 
% 2 points to view the first side of the polygon. 
% Clicking the right mouse button exits the polygon tracking phase and 
% automatically close by joing the first and last point. 
%
% INPUT
%
% Catalog : seismic catalog in ZMAP format
%
% OUTPUT 
%
% Figure : figure with topographic map, epicenters of the 
%          events, selection polygon, and legend
%
% Polygon : selection polygon in two-columns LON LAT format
%
% Catalog_Ok : seismic catalog in polygon in ZMAP format
%

% Identification of geographical limits of interest
LatMax = max(Catalog(:,2)) + 0.5;
LatMin = min(Catalog(:,2)) - 0.5;
LonMax = max(Catalog(:,1)) + 0.5;
LonMin = min(Catalog(:,1)) - 0.5;

% Generate figure
figure

% Setting geographic limits
geolimits([LatMin LatMax],[LonMin LonMax])

% Topology Setup
geobasemap topographic

% Active hold on figure
hold on

% Active box on figure
box on

% Create legend
lg = legend;

% Plot catalog
%geoscatter(Data(:,2), Data(:,1), 3.^Data(:,6), Data(:,7), Marker = ".", DisplayName='Epicenters') ;
geoscatter(Catalog(:,2), Catalog(:,1), 2, Catalog(:,7), Marker = ".", DisplayName='Epicenters') ;
cbar = colorbar ;
cbar.Label.String = 'Depth (km)';

% Latitude and longitude vectors
X = [] ;
Y = [] ;

% Deactivate autoupdate legend
lg.AutoUpdate = "off" ;

% Interactive input for polygon vertices on map
while 1
    [x, y, button] = ginput(1) ;
    if button == 3
        break
    end
    X = [ X ; x ] ;
    Y = [ Y ; y ] ;
    line = [ X, Y] ;
    geoplot(line(:,1),line(:,2),'r')
end 

% Activate autoupdate legend
lg.AutoUpdate = "on";

% Close polygon
X = [ X ; X(1) ] ;
Y = [ Y ; Y(1) ] ;
line = [ X, Y] ;     
geoplot(line(:,1),line(:,2),'r',DisplayName ='Polygon')

% Deactivate hold on figure
hold off

% Output of polygon
Polygon = [ Y, X] ;

% Output of seismic catalog selection
Catalog_Ok = Catalog(inpolygon( Catalog(:,2) , Catalog(:,1) , Polygon(:,2) , Polygon(:,1) ) , : ) ;