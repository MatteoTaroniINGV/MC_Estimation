% Script Step 5:
%
% Selection of the events above the different completeness thresholds in
% order to have the final catalog containing only the complete part of the
% seismicity

% load the seismic catalog of Step 4
Cat = importdata( 'Catalog_4.txt' ) ;

% index of events above the completeness
Ind = find( Cat( : , 6 ) >= Cat( : , 11 ) ) ;

% select only the events above the completeness
Cat_Ok = Cat( Ind , : ) ;

% save the final catalog
save( 'Catalog_5.txt' , 'Cat_Ok' , '-ascii' ) ;


