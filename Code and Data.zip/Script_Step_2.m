% Script 2
% 
% This script produces the depth vs magnitude plot, that is useful to find
% the proper depth interval for the events in a seismic catalog

% load the seismic catalog
Catalog = importdata( 'Catalog_1.txt' ) ;

% interval for depth selection (km)
Depth_Min = 0.5 ;
Depth_Max = 20  ;

% select the events in the depth interval
Catalog_Ok = Catalog( Catalog(:,7) <= Depth_Max & Catalog(:,7) >= Depth_Min , : ) ;

% plot the depth vs the magnitude
plot( Catalog_Ok(:,7) , Catalog_Ok(:,6) , '.k' , 'MarkerSize' , 3 , 'DisplayName', 'Seismic events')

% plot options
box on
xlabel( 'Depth (km)' )
ylabel( 'Magnitude' )

% Create legend
legend

% save the new catalog
save( 'Catalog_2.txt' , 'Catalog_Ok' , '-ascii' )
